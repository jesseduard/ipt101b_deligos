const MY_API_KEY = '8123c0d245msh019850bcb34d194p1986f3jsn4b691c72cda4';
export { MY_API_KEY };