<!doctype html>
<html lang="en">
  <head>
    <title>API Example</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style1.css">
  </head>
  <body>
      <div class="quoteContainer">
        <div id="quote"></div>
        <div id="author"></div>
      </div>
    <script src="js/main.js" type="module"></script>
  </body>
</html>