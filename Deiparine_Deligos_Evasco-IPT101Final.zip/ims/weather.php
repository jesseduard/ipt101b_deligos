<?php
$curl = curl_init();

curl_setopt_array($curl, [
	CURLOPT_URL => "https://weatherbit-v1-mashape.p.rapidapi.com/current?lon=121.7&lat=12.8",
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_TIMEOUT => 30,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "GET",
	CURLOPT_HTTPHEADER => [
		"X-RapidAPI-Host: weatherbit-v1-mashape.p.rapidapi.com",
		"X-RapidAPI-Key: 8123c0d245msh019850bcb34d194p1986f3jsn4b691c72cda4"
	],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
	echo "cURL Error #:" . $err;
} else {
	$data = json_decode($response);
	$temp = $data->data[0]->temp;
	$description = $data->data[0]->weather->description;
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Weather Information</title>
	<style>
		body {
			font-family: Arial, sans-serif;
		}
		.container {
			margin: auto;
			max-width: 600px;
			padding: 20px;
			border: 1px solid #ccc;
			border-radius: 5px;
		}
		.heading {
			font-size: 24px;
			font-weight: bold;
			margin-bottom: 10px;
		}
		.temperature {
			font-size: 48px;
			font-weight: bold;
			margin-bottom: 10px;
		}
		.description {
			font-size: 24px;
			margin-bottom: 10px;
		}
	</style>
</head>
<body>
	<div class="container">
		<div class="heading">Current Philippines Weather Information</div>
		<div class="temperature"><?php echo $temp; ?>°C</div>
		<div class="description"><?php echo $description; ?></div>
	</div>
</body>
</html>
